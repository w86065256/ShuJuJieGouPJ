#include "submit-1AddPolygonBeforeQueryPoint.h"

void SetEnvironmentFromAddPolygonBeforeQueryPoint() {

}

std::vector<int> QueryPointFromAddPolygonBeforeQueryPoint(double x, double y) {
    return std::vector<int>();
}

void AddPolygonFromAddPolygonBeforeQueryPoint(int id, int n, std::vector<std::pair<double, double> > &polygon) {

}
