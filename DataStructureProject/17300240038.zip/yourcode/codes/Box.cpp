#include "Box.h"

namespace yyy
{
	Box::Box(double t,double l,double b,double r)
	{
		top = t;
		lef = l;
		bot = b;
		rig = r;
	}
}