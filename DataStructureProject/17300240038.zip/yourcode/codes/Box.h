#ifndef _YYY_BOX_H_
#define _YYY_BOX_H_

namespace yyy
{
	struct Box
	{
		double top;
		double lef;
		double rig;
		double bot;

		Box(double t,double l,double b,double r);
	};
}

#endif //_YYY_BOX_H_