#include "submit-5MixQueryPolygon.h"
#include "universe.h"

void SetEnvironmentFromMixQueryPolygon() {

}

void AddPointFromMixQueryPolygon(int id, double x, double y) {
	AP;
}

void DeletePointFromMixQueryPolygon(int id) {
	DP;
}

std::vector<int> QueryPolygonFromMixQueryPolygon(int n, std::vector<std::pair<double, double> > &polygon) {
    return QG;
}
