#include "submit-1AddPolygonBeforeQueryPoint.h"
#include "universe.h"

void SetEnvironmentFromAddPolygonBeforeQueryPoint() {
	
}

std::vector<int> QueryPointFromAddPolygonBeforeQueryPoint(double x, double y) {
	return QP;
}

void AddPolygonFromAddPolygonBeforeQueryPoint(int id, int n, std::vector<std::pair<double, double> > &polygon) {
	AG;
}
