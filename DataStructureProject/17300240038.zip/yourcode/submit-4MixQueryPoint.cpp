#include "submit-4MixQueryPoint.h"
#include "universe.h"

void SetEnvironmentFromMixQueryPoint() {

}

std::vector<int> QueryPointFromMixQueryPoint(double x, double y) {
    return QP;
}

void AddPolygonFromMixQueryPoint(int id, int n, std::vector<std::pair<double, double> > &polygon) {
	AG;
}

void DeletePolygonFromMixQueryPoint(int id) {
	DG;
}
